package com.example.bq097t.evaluacionlab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Lista extends AppCompatActivity {


    private AdaptadorEstudiante adaptadorEstudiante;
    public static ArrayList<Estudiante> estudianteArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        estudianteArrayList = new ArrayList<>();

        //inicializar el adaptador
        adaptadorEstudiante = new AdaptadorEstudiante(Lista.this, estudianteArrayList);

        ListView listView =(ListView)findViewById(R.id.lsta);
        //setear el adaptador
        listView.setAdapter(adaptadorEstudiante);
        Cargar();
    }

    public void Cargar(){
        String nombre = getIntent().getStringExtra("Nombre");
        String codigo = getIntent().getStringExtra("Codigo");
        String materia =getIntent().getStringExtra("Materia");
        Double p1 = Double.parseDouble(getIntent().getStringExtra("Parcial1"));
        Double p2 = Double.parseDouble(getIntent().getStringExtra("Parcial2"));
        Double p3 = Double.parseDouble(getIntent().getStringExtra("Parcial3"));

        Estudiante e =new Estudiante(
                nombre,
                codigo,
                materia,
                p1,
                p2,
                p3
        );
        estudianteArrayList.add(e);
        adaptadorEstudiante.notifyDataSetChanged();
    }


}
